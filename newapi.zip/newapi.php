<?php
	/**
	* Plugin name: newapi
	*/
	
	// validate auth
	$realauth = "admin:Ashbury1"; // CHANGE THIS TO YOUR DESIRED API CREDENTIALS
	$userauth = $_POST['auth'];
	/*
	$f = fopen('creds.txt', 'r');
	$realauth = fgets($f);
	fclose($f);
	*/
	$realauth = base64_encode($realauth);
	$realauth = "Basic " . $realauth;
	
	if ($realauth != $userauth) {
		header("HTTP/1.0 401 Unauthorized");
	} else {
		// require wp-load.php to use built-in WordPress functions
		require_once("../../../wp-load.php");
		// require for post_exists
		require_once("../../../wp-admin/includes/post.php");
		
		$postType = 'post'; // set to post or page
		
		$userID = 1; // set to user id ... default to 1?
		
		$postStatus = 'publish';  // future, draft, or publish

		$leadTitle = $_POST['title'];

		$leadContent = $_POST['content'];
		
		$excerpt = $_POST['excerpt'];

		$new_post = array(
		'post_title' => $leadTitle,
		'post_content' => $leadContent,
		'post_excerpt' => $excerpt,
		'post_status' => $postStatus,
		'post_date' => $timeStamp,
		'post_author' => $userID,
		'post_type' => $postType,
		'post_category' => array($categoryID)
		);
		
		// check if post exists
		if (post_exists( $leadTitle )) {
			header("HTTP/1.0 200 OK");
			$finaltext .= 'Post already exists!<br>';
		} else {
		
			$post_id = '';
			$post_id = wp_insert_post($new_post);
			
			$finaltext = '';

			if($post_id){
			
			header("HTTP/1.0 201 Created");
			$finaltext .= 'Post made!<br>';

			} else{
			header("HTTP/1.0 400 Bad Request");
			$finaltext .= 'Check your syntax and try again.<br>';

			}
		}
		echo $finaltext;
	}
	
?>